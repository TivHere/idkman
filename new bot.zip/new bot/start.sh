#!/bin/bash
echo "Starting Brownies Café Bot..."
python3 main.py
